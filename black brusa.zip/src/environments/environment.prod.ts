export const environment = {
  production: false,
  demo: 'demo1',
  SERVER_URL: 'http://18.219.65.148:8081',
  MOLLA_URL: 'http://localhost:1337',
  razorKey:"rzp_test_Lp2CeDDsYiDQLy"
};