export const environment = {
  production: false,
  demo: 'demo1',
  SERVER_URL: 'http://54.183.221.123:8081',
  MOLLA_URL: 'http://localhost:1337',
  razorKey:"rzp_test_Lp2CeDDsYiDQLy"
};