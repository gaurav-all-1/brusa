import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from 'src/app/shared/services/cart.service';
import { MasterService } from 'src/app/shared/services/master.service'; 

@Component({
	selector: 'molla-login-modal',
	templateUrl: './login-modal.component.html',
	styleUrls: ['./login-modal.component.scss']
})

export class LoginModalComponent implements OnInit {
	loginForm:any
	registerForm:any
	error:boolean=false
  message:string=""
  error1:boolean=false
  message1:string=""

	constructor(private masterService:MasterService,private route:Router,private cartService:CartService) { }

	ngOnInit(): void {
		this.loginForm=new FormGroup({
			email:new FormControl("" ,Validators.required),
			password:new FormControl("",Validators.required)
			
		  })

		  this.registerForm=new FormGroup({
			email:new FormControl("" ,Validators.required),
			password:new FormControl("",Validators.required),
			confirmpassword:new FormControl("",Validators.required)
		  })
	}

	onlogin() {
		
			var email=this.loginForm.get("email").value;
			var password=this.loginForm.get("password").value;
			if(email==""||email==undefined){
			  this.error=true;
			  this.message="please enter your email id"
			  
			}else if (password==""|| password==undefined){
			  this.error=true;
			  this.message="please enter your password";
			
			}else{
			  const data={
				"username":email,
				"password":password
			  }
			  this.masterService.methodPost(data,"/login").subscribe((res:any)=>{
				var data=JSON.parse(JSON.stringify(res));
				console.log(data)
				console.log(data.token)
				if(data.token!="" && data.token!=undefined){
				  localStorage.setItem("token", data.token);
				  localStorage.setItem("userId", data.id);
				  
				  this.error=false;
				  this.message="You are logged in"
				  this.route.navigate([" "])

				// var datacart:any = localStorage.getItem('cartDataOffline')
				// var varient:any = localStorage.getItem('offlineVarient')
				// var quantity:any = localStorage.getItem('offlineQuantity')

				// this.cartService.addToCart(datacart,varient,quantity);	

				location.reload()

				}else{
				  this.error=false;
				  this.message="something wrong please check your details"
				}
				
			  })
			   
			}
		 
		  
	}

	userRegister(){
		
		var email=this.registerForm.get("email").value;
		var confirmpassword=this.registerForm.get("confirmpassword").value;
		var password=this.registerForm.get("password").value;
		console.log(email,password)
		if (email=="" || email==undefined || email==null){
		  this.error1=true
		  this.message1="please enter the email ID"
		  
		}else if  (password==""|| password==undefined || password==null){
		  this.error1=true;
		  this.message1="please enter your password"
		}
		else if  (confirmpassword==""|| confirmpassword==undefined || confirmpassword==null){
			this.error1=true;
			this.message1="please enter your password"
		  }else{
			  if(confirmpassword==password){
				const data={
					"email":email,
					"password":password
				  }
				  this.masterService.methodPost(data,"/user/registration").subscribe(res=>{
					var data=JSON.parse(JSON.stringify(res));
					console.log(data)
				   if(data["message"]!=""){
					 this.error1=false;
					 this.message1="you are Registered Please Login"
					 this.route.navigate([" "]);
					 location.reload();
					 
				   }else{
					 this.error1=true
					 this.message1="something wrong please try again"
				   }

				  
			  }
		 )
		 
		  
		}else{
					this.error1=true
					 this.message1="something wrong please try again"
		}
		
	   
	  }
	}

	closeModal() {
		let modal = document.querySelector('.login-modal') as HTMLElement;
		if (modal)
			modal.click();
	}
}