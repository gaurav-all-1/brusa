import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FAQComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
